[![Wednesware](wednesware.png)](https://wednesware.org)

# Nitrogen

Fast installer for Wednesware publications.

## Installation methods:

### From PyPI via pipx (recommended, global install, run with `n2`):
* `pipx install wwn`

### From PyPI via pip (virtual environment or global install, run with `n2`):
* `pip install wwn`
* Note: You may need to create a virtual environment for this method first on some machines. [Learn how to do this here.](https://docs.python.org/3/library/venv.html)

### From GitHub via terminal (local install, run with `python -m nitrogen`):
* `git clone https://github.com/Wednesware/Nitrogen.git nitrogen`

### From Github via browser (local install, run with `python -m nitrogen`):
* [Click here to install the latest Nitrogen release as a zip file](https://github.com/Wednesware/Nitrogen/releases/latest/download/nitrogen.zip) [or click here to browse releases](https://github.com/Wednesware/Nitrogen/releases).
* Unpack using `bsdtar -xf nitrogen.zip`

## Upgrade methods:

### From PyPI
* `pip install wwn --upgrade`

## Usage:

### 

* `n2 get <publication> [release (latest by default)]` - Download a Wednesware publication from GitHub.
  * Example usage: `n2 get magnesium 26.3` (installs Magnesium release 26.3 to `ww/mg26_3`.)
  * Tip: you can use chemical symbols for publications. Example: `n2 get mg 26.3`
* `n2 getlib <project> <publication> [release (latest by default)]` - Download a Wednesware publication to `./<project>/libraries/ww`.
  * Example usage: `n2 getlib app magnesium 26.3` (installs to `./app/libraries/ww/mg26_3`.)
* `n2 rm <publication> [release (all by default)]` - Delete all releases or a specific release of a publication from the current directory.
  * Example usage: `n2 rm magnesium 26.3` (deletes `./ww/magnesium26_3` and `./ww/mg26_3` only if present)
  * Or: `n2 rm magnesium` (deletes all installed versions in `./ww` for both long and short publication names)
  * Tip: you can use chemical symbols here too.
* `n2 install <path> [--name <command>] [--bin <dir>] [--no-deps]` - Install a package directory that contains a valid JSON `.nitropkg` file into the user bin, adding its libraries and project-local `.ww` dependencies automatically.
* `n2 uninstall <command> [--bin <dir>]` - Remove a previously installed Nitrogen package wrapper only if it was created by Nitrogen.
* `n2 getdep [path]` - Search recursively under path for every `.nitrodep` and install dependencies.
* `n2 forcegetdep [path]` - Same as `getdep`, but force reinstall dependencies.
* `n2 updlibs <project>` - Reinstall all libraries found in `./<project>/libraries/ww` by reading installed publication names and versions.
* `n2 help` - Prints a formatted help message to the terminal.
